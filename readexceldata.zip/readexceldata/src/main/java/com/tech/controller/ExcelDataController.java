package com.tech.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.tech.entity.Customer;


@Controller
public class ExcelDataController {
	
	private String fileLocation;
	
	@GetMapping("/show")
	public String show() {
		  
		return "/readdata";
	}	
	
	
	@PostMapping("/uploadnewFile")
	@ResponseBody
	public List<Customer> uploadExcelFile(Model model, MultipartFile file) throws IOException {
	    InputStream in = file.getInputStream();
	    File currDir = new File(".");
	    String path = currDir.getAbsolutePath();
	    fileLocation = path.substring(0, path.length() - 1) + file.getOriginalFilename();
	    
	    	    
	    
	    FileOutputStream f = new FileOutputStream(fileLocation);
	    int ch = 0;
	    while ((ch = in.read()) != -1) {
	        f.write(ch);
	    }
	    f.flush();
	    f.close();
//	    model.addAttribute("message", "File: " + file.getOriginalFilename() 
//	      + " has been uploaded successfully!");
	    List<Customer> customerlist = readXLSXFile(file.getOriginalFilename());
	    for(Customer cust : customerlist){
			   System.out.println(cust);
			  }
	    return  customerlist;
	}
	
	private static List<Customer> readXLSXFile(String file) {
		  List<Customer> listCust = new ArrayList<Customer>();
		  try {
		   XSSFWorkbook work = new XSSFWorkbook(new FileInputStream(file));
		   
		   XSSFSheet sheet = work.getSheet("Sheet1");
		   XSSFRow row = null;
		   int i=0;
		   row = sheet.getRow(i);
		   if(row != null)
		   while((row = sheet.getRow(i))!=null){
		    int custId;
		    String custName,custCity;
		    try{
		     custId = (int) row.getCell(0).getNumericCellValue();
		    }
		    catch(Exception e){custId = 0;}
		    try{
		     custName = row.getCell(1).getStringCellValue();
		    }
		    catch(Exception e){custName = null;}
		    try{
		     custCity = row.getCell(2).getStringCellValue();
		    }
		    catch(Exception e){custCity = null;}
		    
		    Customer cust = new Customer(custId,custName,custCity);
		    listCust.add(cust);
		     i++;    
		   }
		   work.close();
		  } catch (IOException e) {
		   System.out.println("Exception is Customer fetch data :: "+e.getMessage());
		   e.printStackTrace();
		  }
		  return listCust;
		 } 	


}
